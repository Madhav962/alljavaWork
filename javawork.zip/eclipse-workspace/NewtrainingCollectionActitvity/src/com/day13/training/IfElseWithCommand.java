package com.day13.training;



public class IfElseWithCommand {

	public static void main(String[] arr) {
		
		if(arr.length>0)
		{
			System.out.println("Java");
			
		}else
		{
			System.out.print("I Like ");
			String arr2[]= {"s"};
			main(arr2);
			
		}
		

	}

}
