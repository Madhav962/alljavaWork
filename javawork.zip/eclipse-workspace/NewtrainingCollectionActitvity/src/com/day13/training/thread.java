package com.day13.training;

public class thread {
	public static void main(String[] args) {
		
		System.out.println("hi");
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
