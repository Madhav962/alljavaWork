package com.day13.training;

public class FirstLastNameInput {

	public static void main(String[] arr) {
		String FirstName=arr[0];
		String LastName=arr[1];
		System.out.println(FirstName);
		System.out.println(LastName);
		

	}

}
