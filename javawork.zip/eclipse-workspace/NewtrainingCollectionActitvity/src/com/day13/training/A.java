package com.day13.training;

public class A {
	private A()
	{
		
	}
	public void Task2()
	{
		System.out.println("From Task2 of class Task2");
	}
	
}
class Test
{
	Task2();

}
