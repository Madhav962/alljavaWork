package com.day13.training;

import java.util.HashSet;
import java.util.Set;

public class Demo {

	public static void main(String[] args) {
		Set set = new HashSet();;;;;;;;;;;;;;;;
		System.out.println("end");;;;;;;;;;;;;

	}

}
