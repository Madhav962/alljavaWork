package com.test.programs;
import java.util.ArrayList;
import java.util.List;
public class StudentDataImplementation {
	
	
	ArrayList<Q4StringConcatenation> s = null;
	{
		s = new ArrayList<>();
		Q4StringConcatenation std1 = new Q4StringConcatenation(1, "Vijay", 50, 60, 70);
		s.add(std1);
		Q4StringConcatenation std2 = new Q4StringConcatenation(2, "Ram", 50, 60, 70);
		s.add(std2);
		Q4StringConcatenation std3 = new Q4StringConcatenation(3, "Shayam", 50, 60, 70);
		s.add(std3);
			
	}

	public List<Q4StringConcatenation> getAllQ4StringConcatenation()
	{
		return s;
	}
	public void addQ4StringConcatenation(Q4StringConcatenation std) {
		s.add(std);
		
	}
	}



