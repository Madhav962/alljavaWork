package com.test.programs;
import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
public class Q4Controller {
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StudentDataImplementation td =new StudentDataImplementation();
		List<Q4StringConcatenation> list = td.getAllQ4StringConcatenation();
		System.out.println("Enter Student rollno");
		int R = Integer.parseInt(br.readLine());
		System.out.println("Enter student Name");
		String nm = br.readLine();
		System.out.println("Enter student marks in english");
		int e = Integer.parseInt(br.readLine());
		System.out.println("Enter student marks in maths");
		int m = Integer.parseInt(br.readLine());
		System.out.println("Enter student marks in physics");
		int p = Integer.parseInt(br.readLine());
		
		Q4StringConcatenation std = new Q4StringConcatenation(R, nm, e,m,p);
		td.addQ4StringConcatenation(std);
		System.out.println(" display detais of all student");
		System.out.println("Details:");
		list.forEach(System.out::println);
			}
}

