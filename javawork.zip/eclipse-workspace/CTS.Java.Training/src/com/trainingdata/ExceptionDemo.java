package com.trainingdata;

public class Sorting {

	public static void main(String[] args) {
		
		

	}

}
