package com.trainingdata;

import java.util.Scanner;

public class PrimeNumbersBetween {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the Starting Number: ");
    	int StartNumber = input.nextInt();
		System.out.print("Enter the Ending Number: ");
    	int EndNumber = input.nextInt();
		 
	        while (StartNumber < EndNumber) {
	            boolean prime = false;
	            
	            for(int i = 2; i <= EndNumber-1; ++i)
	            {

	                if(StartNumber % i == 0) {
	                    prime = true;
	                    break;
	                }
	            }
	            
	            if (!prime)
	            {
	                System.out.print(StartNumber + " ");
	            ++StartNumber;
	        }

	}

}
}
