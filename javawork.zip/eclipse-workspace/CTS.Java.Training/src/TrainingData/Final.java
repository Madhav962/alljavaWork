package TrainingData;


public class Final
{
	public static final int age;
	 static
		{
			age=10;
		}
		

	
	public static void main(String args[])
	{
		
System.out.println(age);
	}
}