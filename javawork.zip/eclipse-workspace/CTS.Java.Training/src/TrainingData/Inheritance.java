package TrainingData;

public class Inheritance
{
	public static void main(String args[])
	{
	String Person="Jayesh";
	
	int age=20;
	int Empid= 1221;
	
	System.out.println("Person Name: " + Person);
	System.out.println("Person Employeeid " + Empid);
	System.out.println("Person Age: " + age);
}
}