package TrainingData;

import java.util.Scanner;

public class Employee1
{
	char EmpName, EmpDesignation, EmpAddress;
	int EmpId, EmpNumber;
	
	public void getEmployeeData(char n, char d, char a, int i,int nb)
	{
		Scanner sc= new Scanner(System.in);
		String name= sc.next();	
		String designation= sc.next();
		String address= sc.next();
		int id= sc.nextInt();
		int number= sc.nextInt();
		
	}
	public void putEmployeeData(char n, char d, char a, int i,int nb)
	{
		
	}
	
	
}