/**
 * 
 */
function displaySum() {
	document.write(CalculateSum(2,14));
	
}
function CalculateSum(num1,num2) {
	var result=num1+num2;
	return result;
	
}