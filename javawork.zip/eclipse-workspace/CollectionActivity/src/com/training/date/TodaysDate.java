package com.training.date;

import java.time.LocalDate;

public class TodaysDate {

	public static void main(String[] args) {
		
		
		LocalDate date=LocalDate.now();
		System.out.println("Today's date is :"+date);
		
	}

}
