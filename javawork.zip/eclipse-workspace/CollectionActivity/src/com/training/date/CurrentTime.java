package com.training.date;

import java.time.LocalTime;

public class CurrentTime {

	public static void main(String[] args)
	{
		LocalTime current=LocalTime.now();
		System.out.println("Current time is :"+current);

	}

}
