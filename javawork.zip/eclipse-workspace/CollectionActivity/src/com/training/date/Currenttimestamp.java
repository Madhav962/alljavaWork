package com.training.date;

import java.time.Instant;

public class Currenttimestamp {

	public static void main(String[] args) {
		Instant instant= Instant.now();
		System.out.println("Current TImestamp is: "+instant);

	}

}
