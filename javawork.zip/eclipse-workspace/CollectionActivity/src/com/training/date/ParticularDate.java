package com.training.date;

import java.time.LocalDate;

public class ParticularDate {

	public static void main(String[] args) {
		
        LocalDate birthday=LocalDate.of(1996, 07, 15);
		System.out.println("Your birthday is :"+birthday);
		System.out.println();
		

	}

}
