//Convert Char to String

package com.day10.dailytask;

import java.util.Scanner;

public class ChartoString {

	public static void main(String[] args) {
	char c='W';
	String S=Character.toString(c);
	System.out.println("Character implementation into string is as: "+S);
	

	}

}
