//Display current date and Time

package com.day10.dailytask;

import java.time.LocalDateTime;

public class CurrentDateTime {
	public static void main(String args[]) {
		LocalDateTime N= LocalDateTime.now();
		System.out.println("Current date and time is: "+N);
		
	}

}
