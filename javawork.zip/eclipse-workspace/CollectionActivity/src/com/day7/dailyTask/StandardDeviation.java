package com.day7.dailyTask;

import java.util.Scanner;

public class StandardDeviation {

	public static void main(String[] args) {
		double size;
	       Scanner scan = new Scanner(System.in);
		   
	       System.out.print("Enter Array Size : ");
	       size = scan.nextDouble();
	       double arr[]=new double[(int) size];
		   
	       System.out.print("Enter Array Elements : ");
	       for(int i=0; i<size; i++)
	       {
	           arr[i] = scan.nextDouble();
	       }
	        StandardDeviation(arr);
	        System.out.println("Standard Deviation is: "+arr);
	       
	       

	}

	private static double StandardDeviation(double arr[]) {
		
		 double sum = 0.0, standardDeviation = 0.0;
	        double length = arr.length;

	        for(double num : arr) {
	            sum += num;
	        }

	        double mean = sum/length;

	        for(double num: arr) {
	            standardDeviation += Math.pow(num - mean, 2);
	        }

	        return Math.sqrt(standardDeviation/length);
	    }
		
	}


