package com.day12.training;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.cts.training.bean.Employee;

public class EmployeeStream {

	public static void main(String[] args) {
		ArrayList<Employee> employees= new ArrayList<>();
		addEmployees(employees);
		System.out.println();
		//1. Employees with Age Greater Than 20
		
		List<Employee> agefilter= employees.stream().filter(e->e.getAge()>20).collect(Collectors.toList());
        System.out.println("******Employee with Age Greater Than 20*******");
        System.out.println();
        agefilter.forEach(System.out::println);
        System.out.println();
        
        //2. Employees whose name Starts with 'N'
        List<Employee> namefilter= employees.stream().filter(e->e.getName().startsWith("N")).collect(Collectors.toList());
        System.out.println("**********Employees whose name starts with N *********");
        System.out.println();
        namefilter.forEach(System.out::println);
        System.out.println();
        
        //3. Employee salary increase by 15%
        List<Employee> incrementfilter= employees.stream().map(e->{e.setSalary(e.getSalary()*1.15);return e;}).collect(Collectors.toList());
        System.out.println("*********Employee with 15% increased salary*************");
        System.out.println();
        incrementfilter.forEach(System.out::println);
        System.out.println();
        
        //4. Employee by Mr. and Mrs.
        List<Employee> MrMsfilter= employees.stream().map(e->{
        	if(e.getId()%2==0) {e.setName("Mr."+e.getName());return e;}
        	else {e.setName("Ms."+e.getName());return e;}}).collect(Collectors.toList());
        System.out.println("********Employee Names with Mr. & Ms.**********");
        System.out.println();
        MrMsfilter.forEach(System.out::println);
        }
        
        
	

	private static void addEmployees(ArrayList<Employee> employees) {
		{
			Employee emp1 = new Employee(4234, "Vijay", "Bangalore", "Developer", 20, 41241.89, 79879798L);
			Employee emp2 = new Employee(2324, "Neeraj", "Mumbai", "Software Engineer", 21, 23434.89, 121313L);
			Employee emp3 = new Employee(9987, "Sakshi", "Indore", "Test Engineer", 19, 19889.80, 979879798L);
			Employee emp4 = new Employee(1235, "Neha", "Pune", "DevOps Engineer", 23, 68908.12, 43432222L);
			Employee emp5 = new Employee(1245, "Neerja", "Bhopal", "Engineer", 22, 689908.12, 4343256222L);
			employees.add(emp1);
			employees.add(emp2);
			employees.add(emp3);
			employees.add(emp4);
			employees.add(emp5);
		}
		
	}

}
