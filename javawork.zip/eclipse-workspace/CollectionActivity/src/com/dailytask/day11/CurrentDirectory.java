//Program to Get Current Working Directory


package com.dailytask.day11;

public class CurrentDirectory {

	public static void main(String[] args) {
		
		 String path = System.getProperty("user.dir");
	     System.out.println("Working Directory = " + path);


	}

}
