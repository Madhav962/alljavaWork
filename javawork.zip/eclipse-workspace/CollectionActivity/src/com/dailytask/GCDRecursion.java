package com.dailytask;

import java.util.Scanner;

public class GCDRecursion {

	public static int  GCDR(int n1,int n2)
	{
		if (n2 != 0)
            return GCDR(n2, n1 % n2);
        else
            return n1;

	}
	
		public static void main(String[] args) {
			Scanner input = new Scanner(System.in);
			System.out.print("Enter a FirstNumber: ");
	    	int Number = input.nextInt();
	    	System.out.print("Enter a SecondNumber: ");
	    	int NUmber2 = input.nextInt();
		    System.out.print("The GCD is: ");
			int GCD=GCDR (Number,NUmber2);
			System.out.println(GCD);
			
		}
}

